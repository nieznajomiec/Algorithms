import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class HelloGoodbye
{
    public static void main(String args[])
    {
    	System.out.print( "Hello " + args[0] + " and " + args[1] + ".\n" + "Goodbye " + args[1] + " and " + args[0] + ".");
    }
}
